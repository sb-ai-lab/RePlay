# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sponge_bob_magic',
 'sponge_bob_magic.dashboard',
 'sponge_bob_magic.datasets',
 'sponge_bob_magic.datasets.data_loader',
 'sponge_bob_magic.models',
 'sponge_bob_magic.scenarios',
 'sponge_bob_magic.splitters']

package_data = \
{'': ['*']}

install_requires = \
['annoy==1.16.3',
 'dash-core-components==1.7.0',
 'dash-html-components==1.0.2',
 'dash-table==4.6.0',
 'dash==1.8.0',
 'joblib==0.14.1',
 'lightfm==1.15',
 'numpy==1.17.2',
 'optuna==0.16.0',
 'pandas==0.25.1',
 'plotly==4.5.0',
 'psutil==5.6.7',
 'pyarrow==0.14.1',
 'pyspark==2.4.4',
 'scipy==1.4.1',
 'torch==1.4.0',
 'tqdm==4.42.1']

setup_kwargs = {
    'name': 'sponge-bob-magic',
    'version': '0.1.0',
    'description': 'Библиотека рекомендательных систем',
    'long_description': '# Sponge Bob Magic\n\nЭта библиотека должна, как губка, впитать в себя магию из других\nбиблиотек, посвящённых рекомендательным системам.\n\n## Как присоединиться к разработке\n\n```bash\ngit clone ssh://git@10.21.25.60:8878/ailab/sponge-bob-magic.git\ncd sponge-bob-magic\npython3 -m venv .\nsource ./bin/activate\npip install -r requirements.txt\n```\n\n## Как проверить качество кода\n\nИз виртуального окружения\n\n```bash\n./show_report.sh\n```\n',
    'author': 'Шминке Борис',
    'author_email': 'Shminke.B.A@sberbank.ru',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://sbtatlas.sigma.sbrf.ru/stash/scm/ailab/sponge-bob-magic',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
